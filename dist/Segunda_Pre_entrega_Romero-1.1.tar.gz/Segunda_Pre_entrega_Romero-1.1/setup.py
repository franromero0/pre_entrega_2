from setuptools import setup

setup(
    name="Segunda_Pre_entrega_Romero",
    version="1.1",
    description="...",
    author="Francisco Nahuel Romero",
    author_email="francisconahuel09@gmail.com"
      )


