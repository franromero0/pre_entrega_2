def vernotas():
    print("""
La clase cliente tiene:

               
Atributos: nombre,edad,pais,intereses,usuario,email,carrito

Metodos: .__str__(), .verdatos(), .comprar(), .añadircarrito(), removercarrito()

* Los modulos son 3 y se llaman: 
                                   - clase_cliente        (Donde esta ubicado Cliente())
                                   - pre_entrega_1        (Funciones varias)
                                   - programa             (Codigo para ejecutar el programa de manera ordenada)
                                   "Se recomienda ejecutar el modulo programa.py para ver el programa completo"


* Importante cambiar la ruta en el modulo pre_entrega_1 a la suya en ruta_archivo para poder ejecutar "main.py"

""")